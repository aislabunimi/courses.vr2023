using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public string myName;

    public GameObject cube;
    
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Hello " + myName);
    } 

    // Update is called once per frame
    void Update()
    {
        
    }
}
