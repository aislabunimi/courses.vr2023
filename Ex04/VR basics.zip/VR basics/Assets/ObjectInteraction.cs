using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectInteraction : MonoBehaviour
{
    public GameObject objectToSpawn;

    public AudioSource clip;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ActivateStart()
  
    {
        //GameObject newObject;
        //newObject = Instantiate(objectToSpawn, new Vector3(0, 0, 0), new Quaternion(0, 0, 0, 0));

        clip.Play();
    }

}
