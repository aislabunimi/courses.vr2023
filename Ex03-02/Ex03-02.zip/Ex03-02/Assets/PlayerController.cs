using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rb_player;
    public float speed;
    private Vector3 movementInput;
    private Animator an_player;

    // Start is called before the first frame update
    void Start()
    {
        rb_player = GetComponent<Rigidbody>();
        an_player = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        movementInput = new Vector3(Input.GetAxis("Horizontal")*speed, 0f, Input.GetAxis("Vertical")*speed);
 
    }

    private void FixedUpdate()
    {
        rb_player.velocity = movementInput;

        an_player.SetFloat("speed", rb_player.velocity.magnitude);
    }
}

