using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//XR interaction toolkit
using UnityEngine.XR;
//logger
using System.Linq;
using TMPro;
using System;

public class XRinput_demo : MonoBehaviour
{
    //store all connected devices
    List<InputDevice> devices = new List<InputDevice>();

    //hand devices
    InputDevice targetLeftHand;
    InputDevice targetRightHand;

    //head device
    InputDevice targetHead;

    //check if the target device has been found
    private bool deviceFound = false;

    //logger
    public TextMeshProUGUI logArea;
    private int maxLines = 15;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        if (!deviceFound)
        {
            Initialize();
        } 
        else
        {
            
            //obtain the head velocity value
            Vector3 headVel = GetHeadsetVelocityValue(targetHead);
            //print the head velocity magnitude logs
            LogInfo(headVel.magnitude.ToString());
            
            /*
            //obtain the trigger pressure value
            float triggerPressure = GetLeftTriggerPressure(targetLeftHand);
            //print the trigger pressure logs
            LogInfo(triggerPressure.ToString());
            */
        }
 
    }

    private void Initialize()
    {
        
        //find the hmd in 'device' list
        InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeadMounted, devices);

        //find the left controller in 'device' list
        //InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left, devices);

        if (devices.Count > 0)
        {
            
            //assign the hmd to the targetHead variable
            targetHead = devices[0];
            
            /*
            //assign the left controller to the targetLeftHand variable
            targetLeftHand = devices[0];
            */
            deviceFound = true;

        } else
        {
            deviceFound = false;
            Debug.Log("Device not found");
        }

    }

    //LOGGER FUNCTIONS
    private void LogInfo(string message)
    {
        ClearLines();
        logArea.text += $"{DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss")} {message}\n";
    }


    private void ClearLines()
    {
        if (logArea.text.Split('\n').Count() >= maxLines)
        {
            logArea.text = string.Empty;
        }
    }


    //input features

    //HEAD VALUES 

    //Velocities
    private Vector3 GetHeadsetVelocityValue(InputDevice targetHead)
    {
        Vector3 headsetVelocity;

        if (targetHead.TryGetFeatureValue(CommonUsages.deviceVelocity, out Vector3 headsetVelocityValue))
        {
            headsetVelocity = headsetVelocityValue;
        }
        else
        {
            headsetVelocity = Vector3.zero;
        }

        return headsetVelocity;
    }

    private Vector3 GetHeadsetAngularVelocityValue(InputDevice targetHead)
    {

        Vector3 angularVel;

        if (targetHead.TryGetFeatureValue(CommonUsages.deviceAngularVelocity, out Vector3 angVel))
        {
            angularVel = angVel;
        }
        else
        {
            angularVel = Vector3.zero;
        }
        return angularVel;
    }

    //Accelerations
    private Vector3 GetHeadsetAccelerationValue(InputDevice targetHead)
    {
        Vector3 headsetAcceleration;

        if (targetHead.TryGetFeatureValue(CommonUsages.deviceAcceleration, out Vector3 headsetAccelerationValue))
        {
            headsetAcceleration = headsetAccelerationValue;
        }
        else
        {
            headsetAcceleration = Vector3.zero;
        }

        return headsetAcceleration;
    }

    private Vector3 GetHeadsetAngularAccelerationValue(InputDevice targetHead)
    {
        Vector3 angularAcc;

        if (targetHead.TryGetFeatureValue(CommonUsages.deviceAngularAcceleration, out Vector3 angAcc))
        {
            angularAcc = angAcc;
        }
        else
        {
            angularAcc = Vector3.zero;
        }
        return angularAcc;
    }


    //HANDS VALUES 

    //Velocities
    private Vector3 GetRightHandVelocityValue(InputDevice targetRightHand)
    {
        Vector3 rightHandVelocity;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.deviceVelocity, out Vector3 rightHandVelocityValue))
        {
            rightHandVelocity = rightHandVelocityValue;
        }
        else
        {
            rightHandVelocity = Vector3.zero;
        }

        return rightHandVelocity;
    }

    private Vector3 GetLeftHandVelocityValue(InputDevice targetLeftHand)
    {
        Vector3 leftHandVelocity;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.deviceVelocity, out Vector3 leftHandVelocityValue))
        {
            leftHandVelocity = leftHandVelocityValue;
        }
        else
        {
            leftHandVelocity = Vector3.zero;
        }

        return leftHandVelocity;
    }

    private Vector3 GetRightHandAngularVelocityValue(InputDevice targetRightHand)
    {
        Vector3 rightHandAngularVel;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.deviceAngularVelocity, out Vector3 rightHandAngVel))
        {
            rightHandAngularVel = rightHandAngVel;
        }
        else
        {
            rightHandAngularVel = Vector3.zero;
        }
        return rightHandAngularVel;
    }

    private Vector3 GetLeftHandAngularVelocityValue(InputDevice targetLeftHand)
    {
        Vector3 leftHandAngularVel;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.deviceAngularVelocity, out Vector3 leftHandAngVel))
        {
            leftHandAngularVel = leftHandAngVel;
        }
        else
        {
            leftHandAngularVel = Vector3.zero;
        }
        return leftHandAngularVel;
    }

    //Accelerations
    private Vector3 GetRightHandAccelerationValue(InputDevice targetRightHand)
    {
        Vector3 rightHandAcceleration;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.deviceAcceleration, out Vector3 rightHandAccelerationValue))
        {
            rightHandAcceleration = rightHandAccelerationValue;
        }
        else
        {
            rightHandAcceleration = Vector3.zero;
        }

        return rightHandAcceleration;
    }

    private Vector3 GetLeftHandAccelerationValue(InputDevice targetLeftHand)
    {
        Vector3 leftHandAcceleration;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.deviceAcceleration, out Vector3 leftHandAccelerationValue))
        {
            leftHandAcceleration = leftHandAccelerationValue;
        }
        else
        {
            leftHandAcceleration = Vector3.zero;
        }

        return leftHandAcceleration;
    }

    private Vector3 GetRightHandAngularAccelerationValue(InputDevice targetRightHand)
    {
        Vector3 rightHandAngularAcc;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.deviceAngularAcceleration, out Vector3 rightHandAngAcc))
        {
            rightHandAngularAcc = rightHandAngAcc;
        }
        else
        {
            rightHandAngularAcc = Vector3.zero;
        }
        return rightHandAngularAcc;
    }

    private Vector3 GetLeftHandAngularAccelerationValue(InputDevice targetLeftHand)
    {
        Vector3 leftHandAngularAcc;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.deviceAngularAcceleration, out Vector3 leftHandAngAcc))
        {
            leftHandAngularAcc = leftHandAngAcc;
        }
        else
        {
            leftHandAngularAcc = Vector3.zero;
        }
        return leftHandAngularAcc;
    }

    //Grip values
    private float GetRightGripPressure(InputDevice targetRightHand)
    {
        float rightGripPressure;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.grip, out float gripValue))
        {
            rightGripPressure = gripValue;
        }
        else
        {
            rightGripPressure = 0f;
        }

        return rightGripPressure;
    }

    private float GetLeftGripPressure(InputDevice targetLeftHand)
    {
        float leftGripPressure;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.grip, out float gripValue))
        {
            leftGripPressure = gripValue;
        }
        else
        {
            leftGripPressure = 0f;
        }

        return leftGripPressure;
    }

    private int GetRightGripPressed(InputDevice targetRightHand)
    {
        int rightGripPressed;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.gripButton, out bool gripPress))
        {
            if (gripPress == true)
            {
                rightGripPressed = 1;
            }
            else
            {
                rightGripPressed = 0;
            }
        }
        else
        {
            rightGripPressed = 0;
        }
        return rightGripPressed;
    }

    private int GetLeftGripPressed(InputDevice targetLeftHand)
    {
        int leftGripPressed;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.gripButton, out bool gripPress))
        {
            if (gripPress == true)
            {
                leftGripPressed = 1;
            }
            else
            {
                leftGripPressed = 0;
            }
        }
        else
        {
            leftGripPressed = 0;
        }
        return leftGripPressed;
    }

    //Trigger values
    private float GetRightTriggerPressure(InputDevice targetRightHand)
    {
        float rightTriggerPressure;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.trigger, out float triggerValue))
        {
            rightTriggerPressure = triggerValue;
        }
        else
        {
            rightTriggerPressure = 0f;
        }

        return rightTriggerPressure;
    }

    private float GetLeftTriggerPressure(InputDevice targetLeftHand)
    {
        float leftTriggerPressure;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.trigger, out float triggerValue))
        {
            leftTriggerPressure = triggerValue;
        }
        else
        {
            leftTriggerPressure = 0f;
        }

        return leftTriggerPressure;
    }

    private int GetRightTriggerPressed(InputDevice targetRightHand)
    {
        int rightTriggerPressed;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.triggerButton, out bool triggerPress))
        {
            if (triggerPress == true)
            {
                rightTriggerPressed = 1;
            }
            else
            {
                rightTriggerPressed = 0;
            }
        }
        else
        {
            rightTriggerPressed = 0;
        }
        return rightTriggerPressed;
    }

    private int GetLeftTriggerPressed(InputDevice targetLeftHand)
    {
        int leftTriggerPressed;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.triggerButton, out bool triggerPress))
        {
            if (triggerPress == true)
            {
                leftTriggerPressed = 1;
            }
            else
            {
                leftTriggerPressed = 0;
            }
        }
        else
        {
            leftTriggerPressed = 0;
        }
        return leftTriggerPressed;
    }

    //Thumbstick values
    private Vector2 GetRightThumbstickPosition(InputDevice targetRightHand)
    {
        Vector2 rightThumbstickPosition = Vector2.zero;

        if (targetRightHand.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 rightThumbstick))
        {
            rightThumbstickPosition = rightThumbstick;
        }
        else
        {
            rightThumbstickPosition = Vector2.zero;
        }

        return rightThumbstickPosition;
    }

    private Vector2 GetLeftThumbstickPosition(InputDevice targetLeftHand)
    {
        Vector2 leftThumbstickPosition = Vector2.zero;

        if (targetLeftHand.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 leftThumbstick))
        {
            leftThumbstickPosition = leftThumbstick;
        }
        else
        {
            leftThumbstickPosition = Vector2.zero;
        }

        return leftThumbstickPosition;
    }
}

